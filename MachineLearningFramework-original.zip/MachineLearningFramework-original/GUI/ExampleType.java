package GUI;

public enum ExampleType {
	TrainingExample, TestExample
}
