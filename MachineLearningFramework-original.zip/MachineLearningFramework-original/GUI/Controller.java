package GUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import ProblemComponents.Problem;

/**
 * This class is the frame which is displayed when the project is run. The fram contains a menu bar
 * and a content pane which changes everytime an option in the menu bar is selected to do the required
 * function.
 * 
 * @author luke newton, madelyn krasnay
 * @version 2
 *
 */
public class Controller  extends JFrame{
	//serializable ID
	private static final long serialVersionUID = -7251613294872651907L;
	//the problem est we are working with
	protected Problem problem;
	//the index value of the  most recently selected training example
	protected int selectedTrainingExample;
	//the index value of the  most recently selected test example
	protected int selectedTestExample;
	
	/**Constructor*/
	public Controller(){
		//call to parent class JFrame
		super("milestone 4");
		//setup options for frame and create menu bar
		makeFrame();
	}

	/**main function to run program*/
	public static void main(String[] args) {
		Controller controller = new Controller();
		//default contetns of the controller will be displaying the problem examples
		controller.setContentPane(new DisplayProblemContents(new Problem(1)));
		controller.pack();
	}

	/**set up the frame options and contents of the frame*/
	private void makeFrame(){
		//have out program exit on clicking the close icon in top corner
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//define a problem set to work with
		problem = new Problem();
		//create the menu bar for the frame
		makeMenuBar();
		
		pack();
		setVisible(true);
	}

	/**create the menu bar for the frame*/
	private void makeMenuBar(){
		//the menu bar
		JMenuBar menuBar = new JMenuBar();
		//create problem menu
		JMenu problemMenu = new JMenu("Problem");
		
		/*add options to problem menu*/
		JMenuItem createProblem = new JMenuItem("create");
		createProblem.addActionListener(new CreateProblemListener());
		problemMenu.add(createProblem);

		JMenuItem saveProblem = new JMenuItem("save");
		saveProblem.addActionListener(new SaveProblemListener());
		problemMenu.add(saveProblem);

		JMenuItem loadProblem = new JMenuItem("load");
		loadProblem.addActionListener(new LoadProblemListener());
		problemMenu.add(loadProblem);

		JMenuItem editWeights = new JMenuItem("edit weights");
		editWeights.addActionListener(new EditWeightListener());
		problemMenu.add(editWeights);

		//add problem menu to menu bar
		menuBar.add(problemMenu);

		//create training example menu
		JMenu trainingExampleMenu = new JMenu("training example");
		
		/*add options to training example menu*/
		JMenuItem addTrainingExample = new JMenuItem("add");
		addTrainingExample.addActionListener(new AddTrainingExampleListener());
		trainingExampleMenu.add(addTrainingExample);

		JMenuItem removeTrainingExample = new JMenuItem("remove");
		removeTrainingExample.addActionListener(new RemoveTrainingExampleListener());
		trainingExampleMenu.add(removeTrainingExample);

		JMenuItem editTrainingExample = new JMenuItem("edit");
		editTrainingExample.addActionListener(new EditTrainingExampleListener());
		trainingExampleMenu.add(editTrainingExample);
		//add training example menu to menu bar
		menuBar.add(trainingExampleMenu);

		//create test example menu
		JMenu testExampleMenu = new JMenu("test example");
		
		/*add options to test example menu*/
		JMenuItem addTestExample = new JMenuItem("add");
		addTestExample.addActionListener(new AddTestExampleListener());
		testExampleMenu.add(addTestExample);

		JMenuItem removeTestExample = new JMenuItem("remove");
		removeTestExample.addActionListener(new RemoveTestExampleListener());
		testExampleMenu.add(removeTestExample);

		JMenuItem editTestExample = new JMenuItem("edit");
		editTestExample.addActionListener(new EditTestExampleListener());
		testExampleMenu.add(editTestExample);

		JMenuItem predictTestExample = new JMenuItem("predict");
		predictTestExample.addActionListener(new PredictTestListener());
		testExampleMenu.add(predictTestExample);

		//add test example menu to menu bar
		menuBar.add(testExampleMenu);

		//set menu bar visible
		menuBar.setVisible(true);

		setJMenuBar(menuBar);
	}

	
	/**
	 * This method creates a pop-up window containing a textfeild for the number 
	 * of features in a new dataSet and a done button. when the button is pressed 
	 * the method checks if the number is valid, meaning it is a positive integer. 
	 * If the entry is invalid a error message appears. The method only exits after 
	 * a valid Input had been retrieved.
	 * 
	 * @return int: the number of features
	 */
	private int askForNumberOfFeatures() {
		int numOfFeatures = 0;

		final JTextField numOfFeaturesFeild = new JTextField(10);

		JPanel initPanel = new JPanel();
		initPanel.add(new JLabel("Number of features:"));
		initPanel.add(numOfFeaturesFeild);

		do {
			String result = JOptionPane.showInputDialog(initPanel, "Enter number of features in each data point");

			//cancel was selected in previous input dialog
			if(result.equals(null)){
				setContentPane(new DisplayProblemContents(problem));
			}

			//Attempt to parse to int
			try{
				numOfFeatures = Integer.parseInt(result);
			} 
			//show error message
			catch(NumberFormatException err) {
				JOptionPane.showMessageDialog(null, "Error: Please enter a valid positive integer");
			}      

		} while(numOfFeatures == 0);

		return numOfFeatures;
	}
	
	/**action listener for creating a new problem set*/
	private class CreateProblemListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			//set contents to create new problem set
			setContentPane(new CreateProblemPanel(askForNumberOfFeatures(), problem));
			pack();
		}
	}
	
	/**action listener for editing the weights of a problem*/
	private class EditWeightListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			//set contents to edit weights
			setContentPane(new EditWeightPanel(problem));
			pack();
		}
	}
	
	/**action listener to save the current contents of the problem*/
	private class SaveProblemListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			try {
				problem.serializedExport();
			} catch (Exception e1) {
				System.out.println("Export failed");
			}
		}
	}
	
	/**action listener to load a problem into program from a predefined file*/
	private class LoadProblemListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			try {
				problem.serializedImport();
			} catch (Exception e1) {
				System.out.println("import failed");
				return;
			} 
			
			//if the contetns of the problem is currently being displayed, it need to be updated to show import
			if(getContentPane() instanceof DisplayProblemContents){
				((DisplayProblemContents)getContentPane()).updateProblem(problem);
				pack();
			}
		}
	}
	
	/**Action listener to add a training example to the problem set*/
	private class AddTrainingExampleListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			//set contents to add a new training example
			setContentPane(new AddExamplePanel(ExampleType.TrainingExample, problem));
			pack();
		}
	}
	
	/**Action listener to add a test example to the problem set*/
	private class AddTestExampleListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			//set contents to add a new test example
			setContentPane(new AddExamplePanel(ExampleType.TestExample, problem));
			pack();
		}
	}
	
	/**Action listener to edit a training example in the problem set*/
	private class EditTrainingExampleListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			//set contents to edit a training example
			setContentPane(new EditExamplePanel(ExampleType.TrainingExample, problem, selectedTrainingExample));
			pack();
		}
	}
	
	/**Action listener to edit a test example in the problem set*/
	private class EditTestExampleListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			//set contents to edit a test example
			setContentPane(new EditExamplePanel(ExampleType.TestExample, problem, selectedTestExample));
			pack();
		}
	}
	
	/**Action listener to remove a training example from the problem set*/
	private class RemoveTrainingExampleListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			//set contents to remove a training example
			problem.removeTrainingExample(selectedTrainingExample);
			pack();
		}
	}
	
	/**Action listener to remove a test example from the problem set*/
	private class RemoveTestExampleListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			//set contents to remove a test example
			problem.removeTestExample(selectedTestExample);
			pack();
		}
	}
	
	/**Action listener to predict an output value for a test example int the problem set*/
	private class PredictTestListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			//set contents to predict a test example output
			setContentPane(new PredictTestPanel(problem, selectedTestExample));
			pack();
		}
	}
}
