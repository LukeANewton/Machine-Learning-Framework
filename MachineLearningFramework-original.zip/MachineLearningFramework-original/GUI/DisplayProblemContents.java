package GUI;

import java.awt.*;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import ProblemComponents.Feature;
import ProblemComponents.Problem;

/**
 * This class is the contents and functionality to display the problem contents
 * 
 * @author luke newton, madelyn krasnay
 * @version 3
 */
public class DisplayProblemContents extends Container {
	//serialized ID
	private static final long serialVersionUID = -5170428175418141225L;
	//current problem set working with
	private Problem problem;
	//list to display training examples
	protected JList<ArrayList<Feature>> trainingExamples;
	//list to display test examples
	protected JList<ArrayList<Feature>> testExamples;

	/**
	 * Constructor
	 * 
	 * @param problem problem set currently working with
	 */
	public DisplayProblemContents(Problem problem){
		super();
		this.problem = problem;

		createContent();
	}

	/**create contents to display problem*/
	private void createContent(){
		//clear the controller
		removeAll();

		//create JPanel for TrainingExamples
		JPanel trainingExamplePanel = new JPanel(); 
		trainingExamplePanel.setLayout(new GridBagLayout());
		GridBagConstraints trainingExamplePanelConstraints = new GridBagConstraints();
		//label to describe JList contents at the top left corner
		trainingExamplePanelConstraints.gridx = 0;
		trainingExamplePanelConstraints.gridy = 0;
		trainingExamplePanel.add(new JLabel("Training Examples"), trainingExamplePanelConstraints);
		//create JList for training examples
		trainingExamples = new JList<ArrayList<Feature>>(problem.getTrainingExamples().getDataSet());
		//can only select one example at a time
		trainingExamples.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		//add listener for selecting a new training example
		trainingExamples.addListSelectionListener(new SelectTrainingExampleListener());
		//add training example list to Training Example Panel below the label
		trainingExamplePanelConstraints.gridy = 1;//one below the label
		trainingExamplePanel.add(trainingExamples, trainingExamplePanelConstraints);

		//create JPanel for TrainingExamples
		JPanel testingExamplePanel = new JPanel();
		testingExamplePanel.setLayout(new GridBagLayout());
		GridBagConstraints testingExamplePanelConstraints = new GridBagConstraints();
		//label to describe JList contents at the top of the panel
		testingExamplePanelConstraints.gridx = 0;
		testingExamplePanelConstraints.gridy = 0;
		testingExamplePanel.add(new JLabel("Test Examples"), testingExamplePanelConstraints);
		//create JList for test examples
		testExamples = new JList<ArrayList<Feature>>(problem.getTestExamples().getDataSet());
		//can only select one example at a time
		testExamples.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		//add listener for selecting a new test example
		testExamples.addListSelectionListener(new SelectTestExampleListener());
		//add test example list to TestingExamplePanel
		testingExamplePanelConstraints.gridy = 1;//one below the JLabel
		testingExamplePanel.add(testExamples, testingExamplePanelConstraints);

		//set the layout of the container to GridBag
		setLayout(new GridBagLayout());
		GridBagConstraints panelPlacement = new GridBagConstraints();

		//example panels should go the entire with of the controller
		panelPlacement.fill = GridBagConstraints.HORIZONTAL;
		panelPlacement.anchor = GridBagConstraints.WEST;

		//place the Training example panel at the top left corner
		panelPlacement.gridx = 0;//left of controller
		panelPlacement.gridy = 0;//top of controller
		add(trainingExamplePanel, panelPlacement);

		//place the testing example panel below the Training Examples
		panelPlacement.gridy = 1;//one below the training examples 
		add(testingExamplePanel, panelPlacement);
	}

	/**
	 * update problem set and JLists. Used when importing a new problem set
	 * 
	 * @param problem new problem set to watch with JLists
	 */
	protected void updateProblem(Problem problem){
		this.problem = problem;
		trainingExamples.setModel(problem.getTrainingExamples().getDataSet());
		testExamples.setModel(problem.getTestExamples().getDataSet());
	}

	/*listener for changing the selected training example*/
	private class SelectTrainingExampleListener implements ListSelectionListener{
		/*this warning is given in casting e.getSource() to JList<ArrayList<Feature>>.
		 * This is suppressed because there is only on object using this listener and it is
		 * of type JList<ArrayList<Feature>>, so there will never be a ClassCastException thrown here
		 */
		@SuppressWarnings("unchecked")
		@Override
		public void valueChanged(ListSelectionEvent e) {
			Controller controller = (Controller) SwingUtilities.windowForComponent((JList<ArrayList<Feature>>)e.getSource());
			
			if(problem.getNumberOfTrainingExamples() == 1){
				return;
			}else {
				controller.selectedTrainingExample = trainingExamples.getSelectedIndex();
			}
		}
	}

	/*listener for changing the selected test example*/
	private class SelectTestExampleListener implements ListSelectionListener{
		/*this warning is given in casting e.getSource() to JList<ArrayList<Feature>>.
		 * This is supressed because there is only on object using this listener and it is
		 * of type JList<ArrayList<Feature>>, so there will never be a ClassCastException thrown here
		 */
		@SuppressWarnings("unchecked")
		@Override
		public void valueChanged(ListSelectionEvent e) {
			Controller controller = (Controller) SwingUtilities.windowForComponent((JList<ArrayList<Feature>>)e.getSource());
			
			if(problem.getNumberOfTestExamples() == 1){
				return;
			}else {
				controller.selectedTestExample = testExamples.getSelectedIndex();
			}
		}
	}
}