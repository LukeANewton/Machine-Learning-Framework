package DistanceMetrics;

/**
 * Distance function to work with string values. gives a distance based on length of strings passed
 * 
 * @author Cameron Rushton Luke Newton
 * @version 2
 */


public class StringDistanceLength implements DistanceFunction{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4596542671721605648L;

	/*
	 * Calculates the absolute distance between two strings.
	 * 
	 * @param obj1 first object in difference calculation. Only strings can call this so we know this is a string.
	 * @param obj2 second object in difference calculation. Only strings can call this so we know this is a string.
	 * 
	 * @return 0 if the strings are the same length, otherwise 1.
	 */
	@Override
	public double calculate(Object obj1, Object obj2) {
		if (obj1.toString().length() == obj2.toString().length()) return 0;
		return 1;
	}

}
