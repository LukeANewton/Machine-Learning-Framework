package DistanceMetrics;


import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import ProblemComponents.CompositeFeature;
import ProblemComponents.DataSet;
import ProblemComponents.Feature;

/**
 * Test for the String distance calculation. The same string value is a distance 0, otherwise it returns a count of the number
 * of extra characters and number of characters that are different. This can be negative if and only if string 2 is longer and
 * all characters are the same. Each different character (no matter the ASCII value) will add a distance of 1. The shortest string
 * determines how many values will be examined, the rest is considered excess.
 * 
 * 
 * 
 * NOTE: Values for either parameter of calculate are ensured to not be null or the incorrect type elsewhere
 * in the program. Therefore, those values are not tested here as at this level it WILL break, but those values
 * should not be able to be passed to this function
 * 
 * @author Cameron Rushton, Luke Newton
 * @version 2
 */
public class StringDistanceSimilarityTest {

	/*
	 * pass string values directly to function (ie. not obtained from an object) to ensure equality works
	 */
	@Test
	public void testEqualsFromPrimitiveTypesPassed() {
		assertTrue(new StringDistanceSimilarity().calculate("test", "test") == 0);
	}
	
	/*
	 * pass string values directly to function (ie. not obtained from an object) to ensure inequality works
	 */
	@Test
	public void testNotEqualsFromPrimitiveTypesPassed() {
		assertTrue(new StringDistanceSimilarity().calculate("test", "another test") == -11); //3 chars not equal + 8 extra *-1 for long second string
		assertTrue(new StringDistanceSimilarity().calculate("another test", "test") == 11);
	}
	
	/*
	 * pass string values directly to function (ie. not obtained from an object) to ensure inequality works.
	 * the same string in a different case is not considered equal.
	 */
	@Test
	public void testNotEqualsDifferentCasesFromPrimitiveTypesPassed() {
		assertTrue(new StringDistanceSimilarity().calculate("test", "TEST") == 4);
	}
	
	/*
	 * get values from 2 examples to ensure equality works
	 */
	@Test
	public void testEqualsFromExamples() {
		//create dataset
		DataSet dataSet = new DataSet(3);
		//add points to dataset
		ArrayList<Feature> newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("2"));
    	newPoint.add(CompositeFeature.parseFeature("test"));
    	newPoint.add(CompositeFeature.parseFeature("4.6"));
    	dataSet.addPoint(newPoint);
		
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("4"));
    	newPoint.add(CompositeFeature.parseFeature("test"));
    	newPoint.add(CompositeFeature.parseFeature("3.7"));
    	dataSet.addPoint(newPoint);
		
		
		assertTrue(new StringDistanceSimilarity().calculate(dataSet.getPoint(0).get(1).getContents(), dataSet.getPoint(1).get(1).getContents()) == 0);
	}

	/*
	 * get values from 2 examples to ensure inequality works
	 */
	@Test
	public void testNotEqualsFromExamples() {
		//create dataset
		DataSet dataSet = new DataSet(3);
		//add points to dataset
		ArrayList<Feature> newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("2"));
    	newPoint.add(CompositeFeature.parseFeature("potatoes"));
    	newPoint.add(CompositeFeature.parseFeature("4.6"));
    	dataSet.addPoint(newPoint);
		
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("4"));
    	newPoint.add(CompositeFeature.parseFeature("tomatoes"));
    	newPoint.add(CompositeFeature.parseFeature("3.7"));
    	dataSet.addPoint(newPoint);
		
		
		assertTrue(new StringDistanceSimilarity().calculate(dataSet.getPoint(0).get(1).getContents(), dataSet.getPoint(1).get(1).getContents()) == 2);
	}
	
}
