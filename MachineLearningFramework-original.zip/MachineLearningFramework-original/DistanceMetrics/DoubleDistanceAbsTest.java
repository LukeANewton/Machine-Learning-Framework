package DistanceMetrics;


import static org.junit.Assert.*;
import org.junit.Test;

import ProblemComponents.CompositeFeature;

import java.util.Random;

/**
 * Test for the double distance calculation.
 * 
 * NOTE: Values for either parameter of calculate are ensured to not be null or the incorrect type elsewhere
 * in the program. Therefore, those values are not tested here as at this level it WILL break, but those values
 * should not be able to be passed to this function.
 * 
 * @author Cameron Rushton, Luke Newton
 * @version 2
 */
public class DoubleDistanceAbsTest {

	/*
	 * pass double values directly to function (ie. not obtained from an object) to ensure calculation works
	 */
	@Test
	public void testFromPrimitiveTypesPassed() {
		Random r = new Random();
		Double a = r.nextDouble() * 100;
		Double b = r.nextDouble() * 100;
		/*since double math is weird, assertEquals has a third parameter which is an allowable range above/below
		the desired value. For example, this calculates 4.5-2.7=1.700000000002 */
		assertEquals(Math.abs(a-b), new DoubleDistanceAbs().calculate(a, b), 0.001 );
	}
	
	/*
	 * pass double values in feature objects to ensure calculation works
	 */
	@Test
	public void testFromFeaturesPassed() {
		Random r = new Random();
		Double a = r.nextDouble() * 100;
		Double b = r.nextDouble() * 100;
		
		assertEquals(Math.abs(a-b), new DoubleDistanceAbs().calculate(CompositeFeature.parseFeature(a.toString()).getContents(),
				CompositeFeature.parseFeature(b.toString()).getContents()), 0.001);
	}
	
	

}
