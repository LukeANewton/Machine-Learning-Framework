package DistanceMetrics;
/**
 *Distance Function which gives a value based on the difference between 
 * the Unicode representation to the two characters. Ignores case
 * 
 * @author Cameron Rushton Luke Newton
 * @version 2
 */
public class CharacterDistanceDifferenceUnicodeIgnoreCase implements DistanceFunction {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1066372847158540353L;

	/*
	 * calculates the distance between two characters ignoring case
	 * 
	 * @param obj1 first object in difference calculation. Only characters can call this so we know this is a character
	 * @param obj2 second object in difference calculation. Only characters can call this so we know this is a character
	 * 
	 * @return difference between the two character Unicode values
	 */
	@Override
	public double calculate(Object obj1, Object obj2) {
		return Character.toLowerCase((char)obj1)
				- Character.toLowerCase((char)obj2);
	}
	
}


