package DistanceMetrics;

import static org.junit.Assert.*;
import java.util.ArrayList;
import org.junit.Test;

import ProblemComponents.CompositeFeature;
import ProblemComponents.DataSet;
import ProblemComponents.Feature;

/**
 * Test for a character distance metric that sets characters to lower case, 
 * determines the distance between characters while ignoring case. (Can only be 1 or 0 returned)
 * 
 * NOTE: Values for either parameter of calculate are ensured to not be null or the incorrect type elsewhere
 * in the program. Therefore, those values are not tested here as at this level it WILL break, but those values
 * should not be able to be passed to this function.
 * 
 * @author Cameron Rushton, Luke Newton
 * @version 2
 */
public class CharacterDistanceEqualsIgnoreCaseTest {

	/*
	 * Pass character values directly to function (not obtained from an object) to ensure lower case equality works.
	 */
	@Test
	public void testEqualsFromPrimitiveTypesPassedLowerCase() {
		assertTrue(new CharacterDistanceEqualsIgnoreCase().calculate('a', 'a') == 0);
	}
	
	/*
	 * pass character values directly to function (ie. not obtained from an object) to ensure uppercase equality works
	 */
	@Test
	public void testEqualsFromPrimitiveTypesPassedUpperCase() {
		assertTrue(new CharacterDistanceEqualsIgnoreCase().calculate('A', 'A') == 0);
	}
	
	/*
	 * pass character values directly to function (ie. not obtained from an object) to ensure uppercase does not eqaual lowercase
	 */
	@Test
	public void testEqualsFromPrimitiveTypesPassedUpperCaseAndLowerCase() {
		assertTrue(new CharacterDistanceEqualsIgnoreCase().calculate('A', 'a') == 0);
		assertTrue(new CharacterDistanceEqualsIgnoreCase().calculate('a', 'A') == 0);
	}
	/*
	 *  Pass symbols directly into the function (not obtained from an object) to ensure symbols are treated as characters correctly.
	 */
	@Test
	public void testEqualsFromPrimitiveTypesPassedSymbols() {
		assertTrue(new CharacterDistanceEqualsIgnoreCase().calculate('%', '%') == 0);
		assertTrue(new CharacterDistanceEqualsIgnoreCase().calculate(' ', '!') == 1);
		assertTrue(new CharacterDistanceEqualsIgnoreCase().calculate('\n', '\n') == 0);
	}
	/*
	 * get values from 2 examples to ensure equality works
	 */
	@Test
	public void testEqualsFromExamples() {
		//create dataset
		DataSet dataSet = new DataSet(3);
		//add points to dataset
		ArrayList<Feature> newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("2"));
    	newPoint.add(CompositeFeature.parseFeature("R"));
    	newPoint.add(CompositeFeature.parseFeature("4.6"));
    	dataSet.addPoint(newPoint);
		
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("4"));
    	newPoint.add(CompositeFeature.parseFeature("r"));
    	newPoint.add(CompositeFeature.parseFeature("3.7"));
    	dataSet.addPoint(newPoint);
		
		
		assertTrue(new CharacterDistanceEqualsIgnoreCase().calculate(dataSet.getPoint(0).get(1).getContents(), dataSet.getPoint(1).get(1).getContents()) == 0);
	}

	/*
	 * get values from 2 examples to ensure inequality works
	 */
	@Test
	public void testNotEqualsFromExamples() {
		//create dataset
		DataSet dataSet = new DataSet(3);
		//add points to dataset
		ArrayList<Feature> newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("2"));
    	newPoint.add(CompositeFeature.parseFeature("r"));
    	newPoint.add(CompositeFeature.parseFeature("4.6"));
    	dataSet.addPoint(newPoint);
		
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("4"));
    	newPoint.add(CompositeFeature.parseFeature("#"));
    	newPoint.add(CompositeFeature.parseFeature("3.7"));
    	dataSet.addPoint(newPoint);
		
		
		assertTrue(new CharacterDistanceEqualsIgnoreCase().calculate(dataSet.getPoint(0).get(1).getContents(), dataSet.getPoint(1).get(1).getContents()) == 1);
	}
	
}


