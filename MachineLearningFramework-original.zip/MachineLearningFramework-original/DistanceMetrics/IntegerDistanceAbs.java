package DistanceMetrics;

/**
 * Distance function to work with integers which calculates the absolute distance between two
 * 
 * @author Cameron Rushton Luke Newton
 * @version 2
 */

public class IntegerDistanceAbs implements DistanceFunction {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4727052936539442253L;

	/*
	 * Calculates the absolute distance between two integers.
	 * 
	 * @param obj1 first object in difference calculation. Only integers can call this so we know this is an integer.
	 * @param obj2 second object in difference calculation. Only integers can call this so we know this is an integer.
	 * 
	 * @return absolute difference between the two integer values passed.
	 */
	@Override
	public double calculate(Object obj1, Object obj2) {
		return Math.abs((int)obj1 - (int)obj2);
		
	}

}
