package DistanceMetrics;
/**
 * Distance Function which gives a value based on the abs difference between 
 * the Unicode representation to the two characters
 * 
 * @author Cameron Rushton Luke Newton
 * @version 2
 */
public class CharacterDistanceAbsDifferenceUnicode implements DistanceFunction {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2275272771226725351L;

	/*
	 * calculates the absolute distance between two characters
	 * 
	 * @param obj1 first object in difference calculation. Only characters can call this so we know this is a character
	 * @param obj2 second object in difference calculation. Only characters can call this so we know this is a character
	 * 
	 * @return absolute difference between the two character Unicode values
	 */
	@Override
	public double calculate(Object obj1, Object obj2) {
		return Math.abs((char)obj1 - (char)obj2);
	}
	
}
