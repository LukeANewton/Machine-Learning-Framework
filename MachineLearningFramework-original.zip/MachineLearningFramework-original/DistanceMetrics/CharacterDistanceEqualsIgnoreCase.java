package DistanceMetrics;
/**
 * Distance function for characters which checks if two characters are equal while ignoring case
 * 
 * @author Cameron Rushton Luke Newton
 * @version 2
 */
public class CharacterDistanceEqualsIgnoreCase implements DistanceFunction {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8222709967819538657L;

	/*
	 * calculates the distance between two characters ignoring case
	 * 
	 * @param obj1 first object in difference calculation. Only characters can call this so we know this is a character
	 * @param obj2 second object in difference calculation. Only characters can call this so we know this is a character
	 * 
	 * @return 0 if characters are equal, otherwise 1
	 */
	public double calculate(Object obj1, Object obj2) {
		if (Character.toLowerCase((char)obj1)
				== Character.toLowerCase((char)obj2)) {
			return 0;
		}
		return 1;
	}

}