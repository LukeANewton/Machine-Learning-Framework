package DistanceMetrics;

/**
 * Distance function to work with integers which calculates the distance between two
 * 
 * @author luke newton
 * @version 1
 */
public class IntegerDistance implements DistanceFunction {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1890026699372940506L;

	/**
	 * calculates the distance between two integers
	 * 
	 * @param obj1 first object in difference calculation. Only integers can call this so we know this is an integer
	 * @param obj2 second object in difference calculation. Only integers can call this so we know this is an integer
	 * 
	 * @return difference between the two integer values passed
	 */
	public double calculate(Object obj1, Object obj2) {
		return (int)obj1 - (int)obj2;
	}
}
