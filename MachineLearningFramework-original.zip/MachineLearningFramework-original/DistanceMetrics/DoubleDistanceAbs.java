package DistanceMetrics;

/**
 * Distance function to work with doubles that calculates the absolute difference between the two
 * 
 * @author Cameron Rushton Luke Newton
 * @version 2
 */

public class DoubleDistanceAbs implements DistanceFunction {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -135327168598765677L;

	/*
	 * Calculates the absolute distance between two integers.
	 * 
	 * @param obj1 first object in difference calculation. Only doubles can call this so we know this is an double.
	 * @param obj2 second object in difference calculation. Only doubles can call this so we know this is an double.
	 * 
	 * @return absolute difference between the two double values passed.
	 */
	@Override
	public double calculate(Object obj1, Object obj2) {
		return Math.abs((double)obj1 - (double)obj2);
		
	}

}