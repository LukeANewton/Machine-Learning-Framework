package DistanceMetrics;
/**
 * Distance Function for characters which checks for equality
 * 
 * @author luke newton
 * @version 2
 */
public class CharacterDistanceEquals implements DistanceFunction {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6080149185413990803L;

	/**
	 * calculates the distance between two characters
	 * 
	 * @param obj1 first object in difference calculation. Only characters can call this so we know this is an characters
	 * @param obj2 second object in difference calculation. Only characters can call this so we know this is an characters
	 * 
	 * @return difference between the two characters values passed
	 */
	public double calculate(Object obj1, Object obj2) {
		if(((char) obj1) == (char) obj2) return 0;
		return 1;
	}

}
