package DistanceMetrics;
/**
 * Type of DistanceFunction to work with boolean values
 * 
 * @author luke newton
 * @version 1
 */
public class BooleanDistance implements DistanceFunction {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5499757277371536510L;

	/**
	 * calculates the distance between two booleans
	 * 
	 * @param obj1 first object in calculation. Only booleans can call this so we know this is an booleans
	 * @param obj2 second object in calculation. Only booleans can call this so we know this is an booleans
	 * 
	 * @return difference between the two booleans values passed
	 */
	public double calculate(Object obj1, Object obj2) {
		if((boolean) obj1 == (boolean) obj2) return 0;
		return 1;
	}
}
