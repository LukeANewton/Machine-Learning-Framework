package DistanceMetrics;

/**
 * Distance function to work with doubles that calculates the difference between the two of them
 * 
 * @author luke newton
 * @version 1
 */
public class DoubleDistance implements DistanceFunction {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4731621380013581630L;

	/**
	 * calculates the absolute distance between two doubles
	 * 
	 * @param obj1 first object in difference calculation. Only doubles can call this so we know this is an doubles
	 * @param obj2 second object in difference calculation. Only doubles can call this so we know this is an doubles
	 * 
	 * @return difference between the two integer values passed
	 */
	public double calculate(Object obj1, Object obj2) {
		return (double)obj1 - (double)obj2;
	}
}