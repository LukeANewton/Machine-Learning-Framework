package DistanceMetrics;
/**
 * Distance function to work with strings. bases distance off the number of similar characters
 * 
 * @author Cameron Rushton Luke Newton
 * @version 2
 */



import java.lang.Math;

public class StringDistanceSimilarity implements DistanceFunction {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2487106060065378420L;

	/*
	 * Calculates the distance between two strings using compareTo. returns 0 if the strings are equal and for each
	 * character that is not equal, it adds 1 to the return amount. If the first string is longer, 
	 * each excess character adds 1 to the distance. If the second
	 * string is longer, it will subtract the excess number of chars.
	 * 
	 * @param obj1 first object in difference calculation. Only strings can call this so we know this is a string.
	 * @param obj2 second object in difference calculation. Only strings can call this so we know this is a string.
	 * 
	 * @return difference between the two string values passed (number of exactly the same characters; also in the same index)
	 */
	@Override
	public double calculate(Object obj1, Object obj2) {
		
		String str1 = (String)obj1;
		String str2 = (String)obj2;
		
		int distance = 0;
		int maxSize =  Math.min(str1.length(), str2.length());
		distance += Math.max(str1.length(), str2.length()) - maxSize; //add num extra chars
		
		for (int i = 0; i < maxSize; i++) { //compare each char of each string at same indices
			if (str1.charAt(i) != str2.charAt(i)) distance++;
		}
		
		if (str1.length() < str2.length()) distance *= -1; //if string 2 is longer, return a negative
		
		return (double)distance;
	}
	
}
