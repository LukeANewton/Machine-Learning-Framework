package DistanceMetrics;

/**
 * Type of DistanceFunction to work with string values. bases distance
 * off equality of strings
 * 
 * @author luke newton
 * @version 2
 */
public class StringDistanceEquals implements DistanceFunction {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7260405596566634975L;

	/**
	 * calculates the absolute distance between two strings
	 * 
	 * @param obj1 first object in difference calculation. Only strings can call this so we know this is an strings
	 * @param obj2 second object in difference calculation. Only strings can call this so we know this is an strings
	 * 
	 * @return difference between the two integer values passed
	 */
	public double calculate(Object obj1, Object obj2) {
		if(((String) obj1).equals((String) obj2)) return 0;
		return 1;
	}

}
