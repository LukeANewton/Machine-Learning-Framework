package DistanceMetrics;

/**
 * Type of DistanceFunction to work with string values. bases distance
 * off equality of strings while ignoring case
 * 
 * @author luke newton
 * @version 1
 */
public class StringDistanceEqualsIgnoreCase implements DistanceFunction {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6373758154049215613L;

	/**
	 * calculates the absolute distance between two strings
	 * 
	 * @param obj1 first object in difference calculation. Only strings can call this so we know this is an strings
	 * @param obj2 second object in difference calculation. Only strings can call this so we know this is an strings
	 * 
	 * @return difference between the two integer values passed
	 */
	public double calculate(Object obj1, Object obj2) {
		if(((String) obj1).equalsIgnoreCase((String) obj2)) return 0;
		return 1;
	}

}
