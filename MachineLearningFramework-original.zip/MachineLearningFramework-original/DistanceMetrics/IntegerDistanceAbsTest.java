package DistanceMetrics;
import static org.junit.Assert.*;
import org.junit.Test;

import ProblemComponents.CompositeFeature;

import java.util.Random;
/**
 * Test for the absolute integer distance calculation.
 * 
 * NOTE: Values for either parameter of calculate are ensured to not be null or the incorrect type elsewhere
 * in the program. Therefore, those values are not tested here as at this level it WILL break, but those values
 * should not be able to be passed to this function.
 * 
 * @author Cameron Rushton, Luke Newton
 * @version 1
 */
public class IntegerDistanceAbsTest {

	/*
	 * pass integer values directly to function (ie. not obtained from an object) to ensure calculation works
	 */
	@Test
	public void testFromPrimitiveTypesPassed() {
		Random r = new Random();
		Integer a = r.nextInt(100);
		Integer b = r.nextInt(100);
		assertEquals(Math.abs(a-b), new IntegerDistanceAbs().calculate(a, b), 0);
	}
	
	/*
	 * pass integer values in feature objects to ensure calculation works
	 */
	@Test
	public void testFromFeaturesPassed() {
		Random r = new Random();
		Integer a = r.nextInt(100);
		Integer b = r.nextInt(100);
		
		assertEquals(Math.abs(a-b), new IntegerDistanceAbs().calculate(CompositeFeature.parseFeature(a.toString()).getContents(),
				CompositeFeature.parseFeature(b.toString()).getContents()), 0);
	}
	
	

}
