package DistanceMetrics;
/**
 * Distance Function which gives a value based on the abs difference between 
 * the Unicode representation to the two characters. Ignores Case of character
 * 
 * @author Cameron Rushton Luke Newton
 * @version 2
 */

public class CharacterDistanceAbsDifferenceUnicodeIgnoreCase implements DistanceFunction {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8042785310091488759L;

	/*
	 * calculates the absolute distance between two characters ignoring case
	 * 
	 * @param obj1 first object in difference calculation. Only characters can call this so we know this is a character
	 * @param obj2 second object in difference calculation. Only characters can call this so we know this is a character
	 * 
	 * @return absolute difference between the two character Unicode values
	 */
	@Override
	public double calculate(Object obj1, Object obj2) {
		return Math.abs(Character.toLowerCase((char)obj1)
				- Character.toLowerCase((char)obj2));
	}
}

