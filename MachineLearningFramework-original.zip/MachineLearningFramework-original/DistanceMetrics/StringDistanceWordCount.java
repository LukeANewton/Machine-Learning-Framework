package DistanceMetrics;

/**
 * Distance function to work with string values. bases distance off
 * the number of words in each string
 * 
 * @author Cameron Rushton Luke Newton
 * @version 2
 */


public class StringDistanceWordCount implements DistanceFunction {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3976434018344748170L;

	/*
	 * Calculates the distance between two strings using the number of words.
	 * 
	 * @param obj1 first object in difference calculation. Only strings can call this so we know this is a string.
	 * @param obj2 second object in difference calculation. Only strings can call this so we know this is a string.
	 * 
	 * @return 1 if the strings have the same number of words, otherwise 0.
	 */
	@Override
	public double calculate(Object obj1, Object obj2) {
		
		String str1 = obj1.toString().trim().replaceAll("\\s{2,}", " "); //trim all extra space & replace with a single space
		String str2 = obj2.toString().trim().replaceAll("\\s{2,}", " ");
		
		//Done by getting the length, removing the spaces and then subtracting the new length.
		int numSpacesInStr1 = str1.length() - str1.replaceAll(" ", "").length();
		int numSpacesInStr2 = str2.length() - str2.replaceAll(" ", "").length();
		
		if (numSpacesInStr1 != numSpacesInStr2)
			return 1;
		return 0;
	}
	
}
