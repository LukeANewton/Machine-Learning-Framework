package DistanceMetrics;


import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import ProblemComponents.CompositeFeature;
import ProblemComponents.DataSet;
import ProblemComponents.Feature;

/**
 * Test for the String distance calculation. The same string word count is a distance 0, otherwise 1.
 * 
 * values for either parameter of calculate are ensured to not be null or the incorrect type elsewhere
 * in the program. Therefore, those values are not tested here as at this level it WILL break, but those values
 * should not be able to be passed to this function
 * 
 * @author Cameron Rushton, Luke Newton
 * @version 2
 */
public class StringDistanceWordCountTest {

	/*
	 * pass string values directly to function (ie. not obtained from an object) to ensure equality works
	 */
	@Test
	public void testEqualsFromPrimitiveTypesPassed() {
		assertTrue(new StringDistanceWordCount().calculate("test", "test") == 0);
	}
	
	/*
	 * pass string values directly to function (ie. not obtained from an object) to ensure inequality works
	 */
	@Test
	public void testNotEqualsFromPrimitiveTypesPassed() {
		assertTrue(new StringDistanceWordCount().calculate("test", "another test") == 1);
	}
	
	/*
	 * pass string values directly to function (ie. not obtained from an object) to ensure inequality works.
	 * the same string in a different case is not considered equal.
	 */
	@Test
	public void testNotEqualsDifferentCasesFromPrimitiveTypesPassed() {
		assertTrue(new StringDistanceWordCount().calculate("test", "TEST") == 0);
	}
	
	/*
	 * get values from 2 examples to ensure equality works
	 */
	@Test
	public void testEqualsFromExamples() {
		//create dataset
		DataSet dataSet = new DataSet(3);
		//add points to dataset
		ArrayList<Feature> newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("2"));
    	newPoint.add(CompositeFeature.parseFeature("test"));
    	newPoint.add(CompositeFeature.parseFeature("4.6"));
    	dataSet.addPoint(newPoint);
		
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("4"));
    	newPoint.add(CompositeFeature.parseFeature("test"));
    	newPoint.add(CompositeFeature.parseFeature("3.7"));
    	dataSet.addPoint(newPoint);
		
		
		assertTrue(new StringDistanceWordCount().calculate(dataSet.getPoint(0).get(1).getContents(), dataSet.getPoint(1).get(1).getContents()) == 0);
	}

	/*
	 * get values from 2 examples to ensure inequality works
	 */
	@Test
	public void testNotEqualsFromExamples() {
		//create dataset
		DataSet dataSet = new DataSet(3);
		//add points to dataset
		ArrayList<Feature> newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("2"));
    	newPoint.add(CompositeFeature.parseFeature("test"));
    	newPoint.add(CompositeFeature.parseFeature("4.6"));
    	dataSet.addPoint(newPoint);
		
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("4"));
    	newPoint.add(CompositeFeature.parseFeature("another test"));
    	newPoint.add(CompositeFeature.parseFeature("3.7"));
    	dataSet.addPoint(newPoint);
		
		
		assertTrue(new StringDistanceWordCount().calculate(dataSet.getPoint(0).get(1).getContents(), dataSet.getPoint(1).get(1).getContents()) == 1);
	}
	
}
