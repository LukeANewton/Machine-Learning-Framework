package DistanceMetrics;

import java.io.Serializable;

/**
 * interface for distance calculations of different types
 * 
 * @author luke newton
 * @version 1
 */
public interface DistanceFunction extends Serializable{
	public double calculate(Object obj1, Object obj2);
}
