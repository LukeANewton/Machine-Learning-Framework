package InputPanel;

import java.awt.Dimension;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JPanel;

public abstract class InputPanel extends JPanel{

	private String title;
	protected String inputedData;

	/**
	 * Constructor
	 * 
	 *@param tittle : String - the header of the panel object
	 */
	public InputPanel(String title) {
		this.title = title;

		//creates a border around the panel with the tile at the top
		setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder(title),
				BorderFactory.createEmptyBorder(5,5,5,5)));

		//Make the text field group a fixed size
		//to make stacked InputPanels nicely aligned.
		JPanel panelGroup = new JPanel() {
			public Dimension getMinimumSize() {
				return getPreferredSize();
			}
			public Dimension getPreferredSize() {
				return new Dimension(150, super.getPreferredSize().height);
			}
			public Dimension getMaximumSize() {
				return getPreferredSize();
			}
		};
		
		//Setup panel 
		panelGroup.setLayout(new BoxLayout(panelGroup, BoxLayout.PAGE_AXIS));
		panelGroup.setBorder(BorderFactory.createEmptyBorder(0,0,0,5));
		setLayout(new BoxLayout(this, BoxLayout.LINE_AXIS));
		add(panelGroup);
		panelGroup.setAlignmentY(TOP_ALIGNMENT);
	}

	/**	
	 * 	Don't allow this panel to get taller than its preferred size.
	 *	BoxLayout pays attention to maximum size, though most layout
	 *	managers don't.
	 */
	public Dimension getMaximumSize() {
		return new Dimension(Integer.MAX_VALUE, getPreferredSize().height);
	}
	
	/**
	 * Getter for the title.
	 * 
	 * @return String: the title of the panel
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Gets all of the current input in the panel
	 * 
	 * @return String: The inputed data.
	 */
	public String getInput() {
		return inputedData;
	}
}
