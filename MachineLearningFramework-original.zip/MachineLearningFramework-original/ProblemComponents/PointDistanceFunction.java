package ProblemComponents;

/**
 * represents different strategies to calculate the distance between a two points, 
 * each strategy is implemented in KNN.getPointDistances().
 * 
 * @author luke newton
 * @version 2
 *
 */
public enum PointDistanceFunction {
	EuclideanDistance, ManhattanDistance, NumberOfSimilarFeatures, SimpleSummation
}
