package ProblemComponents;

import java.io.Serializable;

import DistanceMetrics.DistanceFunction;

/**
 * Interface for simple features and composite feature.
 * 
 * @author luke newton
 * @version 3
 */
public interface Feature extends Serializable{
	public Object getContents();
	public boolean equals(Feature anotherFeature);
	public String toXML();
	public void setDistanceFunction(DistanceFunction distanceFunction, SimpleFeatureType simpleFeatureType);
}
