package ProblemComponents;

import DistanceMetrics.BooleanDistance;
import DistanceMetrics.CharacterDistanceEquals;
import DistanceMetrics.DistanceFunction;
import DistanceMetrics.DoubleDistance;
import DistanceMetrics.IntegerDistance;
import DistanceMetrics.StringDistanceEquals;

/**
 * The SimpleFeature class. Represents the most basic type of field: 
 * A whole number, floating point, String, character, or boolean. Any type
 * of feature can be built from a combination of these. 
 * 
 * A simple feature also contains the appropriate distance function for that basic feature.
 * 
 * The class contains getters and setters for these two fields, as well as a method for parsing 
 * a string to the appropriate SimpleFeature type.
 * 
 * @author luke newton
 * @version 4
 */
public class SimpleFeature implements Feature{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2760222244853357342L;
	//the actual field value of this feature
	Object contents;
	//the distance function to work with the field value
	DistanceFunction distanceFunction;

	/**
	 * Constructor for creating a SimpleFeature
	 * 
	 * @param contents initial value for the field
	 * @param distFunc distance function that works with the field value
	 */
	public SimpleFeature(Object contents, DistanceFunction distFunc) {
		this.contents = contents;
		this.distanceFunction = distFunc;
	}

	/**
	 * Constructor for creating a SimpleFeature
	 * 
	 * @param contents initial value for the field
	 */
	public SimpleFeature(Object contents) {
		this.contents = contents;
	}

	/** returns the basic field value associated with this feature */
	public Object getContents() {
		return contents;
	}

	/**  returns the feature converted to a string */
	public String toString(){
		return contents.toString(); 
	}

	/** returns the distance function associated with this feature */
	public DistanceFunction getDistanceFuntion() {
		return distanceFunction;
	}

	/** set the distance function to work on this features contents */
	public void setDistanceFunction(DistanceFunction distanceFunction) {
		this.distanceFunction = distanceFunction;
	}

	/** set the contents of this feature */
	public void setContents(Object contents) {
		this.contents = contents;
	}

	/**equals override for SimpleFeature*/
	public boolean equals(Feature anotherFeature){
		//if the features are not of the same type they are unequal
		if(anotherFeature instanceof CompositeFeature)
			return false;

		//if the contents is a string we use equals, otherwise ==
		if(this.getContents() instanceof String){
			if(!this.contents.equals(anotherFeature.getContents()))
				return false;

		}else{
			if(this.contents != anotherFeature.getContents()){
				//doubles are weird, because of how they are represented two identical numbers may be 0.0000000001 apart
				if(Double.class.isInstance(this.contents)){
					if(Math.abs((double)this.contents - (double)anotherFeature.getContents()) > 0.001)
						return false;
				} else {
					return false;
				}
			}
		}
		return true;
	}

	/**crete an XML formatted string*/
	public String toXML(){
		String s = "";

		s += "<SimpleFeature>";

		s += "<contents>";
		s +=   contents;
		s += "</contents>";

		s += "<distanceFunction>";
		s += distanceFunction.getClass().getSimpleName();
		s += "</distanceFunction>";

		s += "</SimpleFeature>";

		return s;
	}

	/**
	 * convert a string value into an appropriate basic field type.
	 *Basic field types are: integer, double, character, string, boolean
	 * 
	 * @param s the input to convert into a SimpleFeature
	 * @return the type of feature contained within the input string. 
	 * Includes value and distance function that works with value
	 */
	public static SimpleFeature parseSimpleFeature(String s){
		if(s.equals("")){
			return null;
		}

		//first try to make a double
		try{
			//if this works, we have either a double or integer
			double n = Double.parseDouble(s);
			//check if its an integer
			if(!s.contains(".")){
				//if there is no decimal, we have an integer
				return new SimpleFeature((int) n, new IntegerDistance());
			}
			//by now we know we have a double
			return new SimpleFeature(n, new DoubleDistance());
		} catch (NumberFormatException e) {
			//System.out.println("not an int or double: " + s);
		}
		//by now, we know its not any kind of number

		//if string is one character long and not a number, its a character
		if(s.length() == 1){
			return new SimpleFeature(s.charAt(0), new CharacterDistanceEquals());
		}

		//if string says 'true' or 'false', its a boolean
		if(s.equalsIgnoreCase("true") || s.equalsIgnoreCase("false")){
			return new SimpleFeature(Boolean.parseBoolean(s), new BooleanDistance());
		}

		//otherwise its a string
		return new SimpleFeature(s, new StringDistanceEquals());
	}

	@Override
	public void setDistanceFunction(DistanceFunction distanceFunction, SimpleFeatureType simpleFeatureType) {
		switch(simpleFeatureType){
		case STRING:
			if(contents instanceof String)
				this.distanceFunction = distanceFunction;
			break;
		case CHARACTER:
			if(contents instanceof Character)
				this.distanceFunction = distanceFunction;
			break;
		case INTEGER:
			if(contents instanceof Integer && !(contents instanceof Double))
				this.distanceFunction = distanceFunction;
			break;
		case DOUBLE:
			if(contents instanceof Double)
				this.distanceFunction = distanceFunction;
		break;
		default:
			//do nothing otherwise
			break;
		}

	}
}
