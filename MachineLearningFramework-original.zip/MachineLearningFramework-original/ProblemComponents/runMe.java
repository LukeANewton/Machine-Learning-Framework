package ProblemComponents;
/**
*this file contains the main function to run the program.
*It also contains a number of test examples the show the program working
*
*@author luke newton
*@version 7
*/

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class runMe {
	static Random rand = new Random();
	
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		//print some examples of the program running correctly, required by deliverable
		housePricingProblem(PointDistanceFunction.SimpleSummation);
		sectionBreak();
		housePricingProblem(PointDistanceFunction.EuclideanDistance);
		sectionBreak();
		housePricingProblem(PointDistanceFunction.ManhattanDistance);
		sectionBreak();
		housePricingProblem(PointDistanceFunction.NumberOfSimilarFeatures);
		sectionBreak();
		sectionBreak();
		soccerGame(PointDistanceFunction.SimpleSummation);
		sectionBreak();
		soccerGame(PointDistanceFunction.EuclideanDistance);
		sectionBreak();
		soccerGame(PointDistanceFunction.ManhattanDistance);
		sectionBreak();
		soccerGame(PointDistanceFunction.NumberOfSimilarFeatures);
	}
	
	/**The soccer game example given by the prof for milestone 3
	 * @param pointDistanceFunction specifies which distance function to use in calculating the distance of a point
	 */
	private static void soccerGame(PointDistanceFunction pointDistanceFunction){
		System.out.println("Test Example 5: Soccer game test as supplied by prof, using " + pointDistanceFunction);
		//weights for prediction
    	double[] weights = {100, 100, 100, 100, 0};
    	//initialize problem
    	Problem problem = new Problem(5, weights);
    	System.out.println("Predicting using equal weights for all fields.");
		//initialize accuracy tracking object
		PredictionError predictionError = new PredictionError();
		
		//add given trainingexamples
    	ArrayList<Feature> newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(1.9, -167)"));
    	newPoint.add(CompositeFeature.parseFeature("(63.8, 31)"));
    	newPoint.add(CompositeFeature.parseFeature("(39.1, -41)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("Kick"));
    	problem.addTrainingExample(newPoint);
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(1.9, 50)"));
    	newPoint.add(CompositeFeature.parseFeature("(63.8, 31)"));
    	newPoint.add(CompositeFeature.parseFeature("(39.1, -41)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("Kick"));
    	problem.addTrainingExample(newPoint);
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(1.8, 2)"));
    	newPoint.add(CompositeFeature.parseFeature("(61.9, -4)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("Kick"));
    	problem.addTrainingExample(newPoint);
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(1.8, -85)"));
    	newPoint.add(CompositeFeature.parseFeature("(53.5, 17)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("Kick"));
    	problem.addTrainingExample(newPoint);
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(19.2, 1)"));
    	newPoint.add(CompositeFeature.parseFeature("(24.6, -17)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("Dash"));
    	problem.addTrainingExample(newPoint);
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(15.9, 1)"));
    	newPoint.add(CompositeFeature.parseFeature("(22.3, -18)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("Dash"));
    	problem.addTrainingExample(newPoint);
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(14.52, 1)"));
    	newPoint.add(CompositeFeature.parseFeature("(20.7, -20)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("Dash"));
    	problem.addTrainingExample(newPoint);
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(11.0, 1)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("(44.8, -5)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("Dash"));
    	problem.addTrainingExample(newPoint);
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(10.0, 1)"));
    	newPoint.add(CompositeFeature.parseFeature("(61.3, -31)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("(41.4, 43)"));
    	newPoint.add(CompositeFeature.parseFeature("Dash"));
    	problem.addTrainingExample(newPoint);
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(45.7, 1)"));
    	newPoint.add(CompositeFeature.parseFeature("(96.6, 2)"));
    	newPoint.add(CompositeFeature.parseFeature("(55.6, -37)"));
    	newPoint.add(CompositeFeature.parseFeature("(55.6, 40)"));
    	newPoint.add(CompositeFeature.parseFeature("Dash"));
    	problem.addTrainingExample(newPoint);
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(50.4, -1)"));
    	newPoint.add(CompositeFeature.parseFeature("(101.5, 14)"));
    	newPoint.add(CompositeFeature.parseFeature("(75.4, -24)"));
    	newPoint.add(CompositeFeature.parseFeature("(46.2, 40)"));
    	newPoint.add(CompositeFeature.parseFeature("Turn"));
    	problem.addTrainingExample(newPoint);
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(41.4, 0)"));
    	newPoint.add(CompositeFeature.parseFeature("(90.1, 18)"));
    	newPoint.add(CompositeFeature.parseFeature("(65.1, -27)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("Turn"));
    	problem.addTrainingExample(newPoint);
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(14.5, 15)"));
    	newPoint.add(CompositeFeature.parseFeature("(60.1, 27)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("Turn"));
    	problem.addTrainingExample(newPoint);
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(41.4, 3)"));
    	newPoint.add(CompositeFeature.parseFeature("(94.7, 4)"));
    	newPoint.add(CompositeFeature.parseFeature("(55.1, -36)"));
    	newPoint.add(CompositeFeature.parseFeature("(53.5, 43)"));
    	newPoint.add(CompositeFeature.parseFeature("Turn"));
    	problem.addTrainingExample(newPoint);
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(23.2, 0)"));
    	newPoint.add(CompositeFeature.parseFeature("(76.9, 2)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("Turn"));
    	problem.addTrainingExample(newPoint);
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(12.0, 24)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("(42.7, -40)"));
    	newPoint.add(CompositeFeature.parseFeature("Turn"));
    	problem.addTrainingExample(newPoint);
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("(26.3, 2)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("Turn"));
    	problem.addTrainingExample(newPoint);
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(3.5, 1)"));
    	newPoint.add(CompositeFeature.parseFeature("(56.1, 4)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("Turn"));
    	problem.addTrainingExample(newPoint);
    	
    	/*predict test examples*/
    	//add test point to DataSet
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(2.0, 22)"));
    	newPoint.add(CompositeFeature.parseFeature("(63.8, -2)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("Kick"));
    	problem.addTestExample(newPoint);
    	System.out.println("Predicting for Ball: (2, 22) Goal: (63.8, -2)");
    	//make prediction
    	Object prediction = Prediction.getPrediction(18, problem, 0, pointDistanceFunction);
    	System.out.println("Prediction: " + prediction + ". Should be: Kick");
    	//update prediction accuracy
    	System.out.println("Prediction accuracy: " + predictionError.updateAccuracy(prediction, "Kick"));
    	System.out.println();
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(2.0, 22)"));
    	newPoint.add(CompositeFeature.parseFeature("(63.8, -2)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("Kick"));
    	problem.addTestExample(newPoint);
    	System.out.println("Predicting for Ball: (2, 22) Goal: (63.8, -2)");    	
    	prediction = Prediction.getPrediction(18, problem, 1, pointDistanceFunction);
    	System.out.println("Prediction: " + prediction + ". Should be: Kick");
    	System.out.println("Prediction accuracy: " + predictionError.updateAccuracy(prediction, "Kick"));
    	System.out.println();
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(1.9, -167)"));
    	newPoint.add(CompositeFeature.parseFeature("(63.8, 31)"));
    	newPoint.add(CompositeFeature.parseFeature("(39.1, -41)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("Kick"));
    	problem.addTestExample(newPoint);
    	System.out.println("Predicting for Ball: (1.9, -167) Goal: (63.8, 31) FCT: (39.1, -41)");
    	prediction = Prediction.getPrediction(18, problem, 2, pointDistanceFunction);
    	System.out.println("Prediction: " + prediction + ". Should be: Kick");
    	System.out.println("Prediction accuracy: " + predictionError.updateAccuracy(prediction, "Kick"));
    	System.out.println();
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(14.5, 0)"));
    	newPoint.add(CompositeFeature.parseFeature("(32.8, 5)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("Turn"));
    	problem.addTestExample(newPoint);
    	System.out.println("Predicting for Ball: (14.5, 0) Goal: (32.8, 5)");
    	prediction = Prediction.getPrediction(18, problem, 3, pointDistanceFunction);
    	System.out.println("Prediction: " + prediction + ". Should be: Turn");
    	System.out.println("Prediction accuracy: " + predictionError.updateAccuracy(prediction, "Turn"));
    	System.out.println();
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("(55.6, 2)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("Turn"));
    	problem.addTestExample(newPoint);
    	System.out.println("Predicting for Goal: (55.6, 2)");
    	prediction = Prediction.getPrediction(18, problem, 4, pointDistanceFunction);
    	System.out.println("Prediction: " + prediction + ". Should be: Turn");
    	System.out.println("Prediction accuracy: " + predictionError.updateAccuracy(prediction, "Turn"));;
    	System.out.println();
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(41.4, 2)"));
    	newPoint.add(CompositeFeature.parseFeature("(95.6, 1)"));
    	newPoint.add(CompositeFeature.parseFeature("(55.1, -38)"));
    	newPoint.add(CompositeFeature.parseFeature("(55.1, 40)"));
    	newPoint.add(CompositeFeature.parseFeature("Turn"));
    	problem.addTestExample(newPoint);
    	System.out.println("Predicting for Ball: (41.4, 2) Goal: (95.6, 1) FCT: (55.1, -38) FCB: (55.1, 40) ");
    	prediction = Prediction.getPrediction(18, problem, 5, pointDistanceFunction);
    	System.out.println("Prediction: " + prediction + ". Should be: Turn");
    	System.out.println("Prediction accuracy: " + predictionError.updateAccuracy(prediction, "Turn"));
    	System.out.println();
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(19.2, 11)"));
    	newPoint.add(CompositeFeature.parseFeature("(85.8, 12)"));
    	newPoint.add(CompositeFeature.parseFeature("(47.5, -34)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("Turn"));
    	problem.addTestExample(newPoint);
    	System.out.println("Predicting for Ball: (19.2, 11) Goal: (85.8, 12) FCT: (47.5, -34)");
    	prediction = Prediction.getPrediction(18, problem, 6, pointDistanceFunction);
    	System.out.println("Prediction: " + prediction + ". Should be: Turn");
    	System.out.println("Prediction accuracy: " + predictionError.updateAccuracy(prediction, "Turn"));
    	System.out.println();
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(23.2, 1)"));
    	newPoint.add(CompositeFeature.parseFeature("(42.7, -4)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("Dash"));
    	problem.addTestExample(newPoint);
    	System.out.println("Predicting for Ball: (23.2, 1) Goal: (42.7, -4)");
    	prediction = Prediction.getPrediction(18, problem, 7, pointDistanceFunction);
    	System.out.println("Prediction: " + prediction + ". Should be: Dash");
    	System.out.println("Prediction accuracy: " + predictionError.updateAccuracy(prediction, "Dash"));
    	System.out.println();
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(21.1, 1)"));
    	newPoint.add(CompositeFeature.parseFeature("(41.9, -4)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("Dash"));
    	problem.addTestExample(newPoint);
    	System.out.println("Predicting for Ball: (23.2, 1) Goal: (41.9, -4)");
    	prediction = Prediction.getPrediction(18, problem, 8, pointDistanceFunction);
    	System.out.println("Prediction: " + prediction + ". Should be: Dash");
    	System.out.println("Prediction accuracy: " + predictionError.updateAccuracy(prediction, "Dash"));
    	System.out.println();
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(50.4, 1)"));
    	newPoint.add(CompositeFeature.parseFeature("(104.5, 1)"));
    	newPoint.add(CompositeFeature.parseFeature("(61.9, -33)"));
    	newPoint.add(CompositeFeature.parseFeature("(61.9, 35)"));
    	newPoint.add(CompositeFeature.parseFeature("Dash"));
    	problem.addTestExample(newPoint);
    	System.out.println("Predicting for Ball: (50.4, 1) Goal: (104.5, 1) FCT: (61.9, -33) FCB: (61.9, 35)");
    	prediction = Prediction.getPrediction(18, problem, 9, pointDistanceFunction);
    	System.out.println("Prediction: " + prediction + ". Should be: Dash");
    	System.out.println("Prediction accuracy: " + predictionError.updateAccuracy(prediction, "Dash"));
    	System.out.println();
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(17.4, 0)"));
    	newPoint.add(CompositeFeature.parseFeature("(91.0, -3)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("(52.9, 39)"));
    	newPoint.add(CompositeFeature.parseFeature("Turn"));
    	problem.addTestExample(newPoint);
    	System.out.println("Predicting for Ball: (17.4, 0) Goal: (91.0, -3) FCB: (52.9, 39)");
    	prediction = Prediction.getPrediction(18, problem, 10, pointDistanceFunction);
    	System.out.println("Prediction: " + prediction + ". Should be: Turn");
    	System.out.println("Prediction accuracy: " + predictionError.updateAccuracy(prediction, "Turn"));
    	System.out.println();
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(10.0, 1)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("(44.4, -9)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("Dash"));
    	problem.addTestExample(newPoint);
    	System.out.println("Predicting for Ball: (10.0, 1) FCT: (44.4, -9)");
    	prediction = Prediction.getPrediction(18, problem, 11, pointDistanceFunction);
    	System.out.println("Prediction: " + prediction + ". Should be: Dash");
    	System.out.println("Prediction accuracy: " + predictionError.updateAccuracy(prediction, "Dash"));
    	System.out.println();
    	
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(10.0, 1)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("(44.4, -8)"));
    	newPoint.add(CompositeFeature.parseFeature(""));
    	newPoint.add(CompositeFeature.parseFeature("Dash"));
    	problem.addTestExample(newPoint);
    	System.out.println("Predicting for Ball: (10.0, 1) FCT: (44.4, -8)");
    	prediction = Prediction.getPrediction(18, problem, 12, pointDistanceFunction);
    	System.out.println("Prediction: " + prediction + ". Should be: Dash");
    	System.out.println("Prediction accuracy: " + predictionError.updateAccuracy(prediction, "Dash"));
	}
	
    /**House price predicting as given on the project handout
     *@param pointDistanceFunction specifies which distance function to use in calculating the distance of a point
     */
    public static void housePricingProblem(PointDistanceFunction pointDistanceFunction){
    	System.out.println("Test example 1: from the file handout using " + pointDistanceFunction);
    	System.out.println();
    	//initialize names for fields (a, b, and c)
    	ArrayList<String> n1 = new ArrayList<>(Arrays.asList("coordinates", "sq.ft.", "age", "price"));
    	//weights for prediction
    	double[] w1 = {100, 100, 100, 0};
    	//initialize problem
    	Problem problem = new Problem(4, n1, w1);
    	//add points
    	System.out.println("adding coordinates = (12,25), sq.ft. = 1200, age = 'new', price = 500000");
    	ArrayList<Feature> newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(12, 25)"));
    	newPoint.add(CompositeFeature.parseFeature("1200"));
    	newPoint.add(CompositeFeature.parseFeature("new"));
    	newPoint.add(CompositeFeature.parseFeature("500000"));
    	problem.addTrainingExample(newPoint);
    	
    	System.out.println("adding coordinates = (10,50), sq.ft. = 1000, age = 'old', price = 300000");
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(10, 50)"));
    	newPoint.add(CompositeFeature.parseFeature("1000"));
    	newPoint.add(CompositeFeature.parseFeature("old"));
    	newPoint.add(CompositeFeature.parseFeature("300000"));
    	problem.addTrainingExample(newPoint);
    	System.out.println("adding coordinates = (30,100), sq.ft. = 800, age = 'new', price = 400000");
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(30, 100)"));
    	newPoint.add(CompositeFeature.parseFeature("800"));
    	newPoint.add(CompositeFeature.parseFeature("new"));
    	newPoint.add(CompositeFeature.parseFeature("400000"));
    	problem.addTrainingExample(newPoint);
    	
    	//add point to estimate
    	newPoint = new ArrayList<>();
    	newPoint.add(CompositeFeature.parseFeature("(15, 20)"));
    	newPoint.add(CompositeFeature.parseFeature("1000"));
    	newPoint.add(CompositeFeature.parseFeature("new"));
    	newPoint.add(CompositeFeature.parseFeature("?"));
    	problem.addTestExample(newPoint);
    	//estimate value1
    	System.out.println("estimate for point: coordinates = (15,20), sq.ft. = 1000, age = 'new':");
    	System.out.println();
    	System.out.println("using weightings: coordinates = 100, sq.ft. = 100, age = 100 (everything equally important)");
    	System.out.println("Prediction: " + Prediction.getPrediction(3, problem, 0, pointDistanceFunction));
    	System.out.println();  	
    }
	
	/*
	 * prints a divider to split up sections in the UI (for readability)
	 * Contributors: Luke Newton
	 */
	private static void sectionBreak(){
		System.out.println("----------------------------------------------------------------------------------------------------------------------------");
		System.out.println();
	}

}