package ProblemComponents;
import static org.junit.Assert.*;

import org.junit.Test;

import java.util.Random;
import java.util.ArrayList;
import java.util.Arrays;
/**
 * tests for DataSet class
 * 
 * @author luke newton
 * @version 1
 *
 */
public class DataSetTest {
	/**
	 * check the size of a data set when initialized with no parameters
	 */
	@Test
	public void testInitializationSizeNoParameters() {
		DataSet data= new DataSet();
		assertTrue(data.getNumberOfPoints() == 0 && data.getNumberOfPoints() == 0);
	}

	/**
	 * check the size of a data set when initization specifies size of each example (number of fields/attributes, elements)
	 */
	@Test
	public void testInitializationSizePassedParameters() {
		Random r = new Random();
		int n = r.nextInt(8);
		DataSet data= new DataSet(n);
		assertTrue(data.getNumberOfPoints() == 0 && data.getNumberOfAttributes() == n);
	}

	/**
	 * test for removal of points
	 */
	@Test
	public void testRemovalOperation(){
		//number of fields in a DataSet
		int n = 3;
		DataSet data= new DataSet(n);

		//add point by passing list of parameters
		data.addPoint(CompositeFeature.parseFeature("1"), CompositeFeature.parseFeature("3.5"), CompositeFeature.parseFeature("true"));
		data.addPoint(CompositeFeature.parseFeature("2"), CompositeFeature.parseFeature("4.6"), CompositeFeature.parseFeature("false"));
		data.addPoint(CompositeFeature.parseFeature("3"), CompositeFeature.parseFeature("5.7"), CompositeFeature.parseFeature("true"));
		data.addPoint(CompositeFeature.parseFeature("4"), CompositeFeature.parseFeature("6.8"), CompositeFeature.parseFeature("false"));
		data.removePoint(2);
		
		//add 4 points, remove one, should have 3 points in end
		assertTrue(data.getNumberOfPoints() == 3);
		//make sure point is removed from index 2 (point previously at index 3 is now at index 2)
		assertTrue((int)data.getPoint(2).get(0).getContents() == 4);
		assertTrue((double)data.getPoint(2).get(1).getContents() == 6.8);
		assertTrue((boolean)data.getPoint(2).get(2).getContents() == false);
	}

	/**
	 * ensure examples are added properly
	 */
	@Test
	public void testCorrectAdditionOfExamples() {
		//number of fields in a DataSet
		int n = 3;
		DataSet data= new DataSet(n);

		//add point by passing list of parameters
		data.addPoint(CompositeFeature.parseFeature("1"), CompositeFeature.parseFeature("3.5"), CompositeFeature.parseFeature("true"));
		assertTrue(data.getNumberOfPoints() == 1);

		//add parameter by passing ArrayList
		ArrayList<Feature> newPoint = new ArrayList<>();
		newPoint.add(CompositeFeature.parseFeature("2"));
		newPoint.add(CompositeFeature.parseFeature("2.4"));
		newPoint.add(CompositeFeature.parseFeature("false"));
		data.addPoint(newPoint);
		assertTrue(data.getNumberOfPoints() == 2);
	}

	/**
	 * ensure points/examples can be retrieved properly 
	 */
	@Test
	public void testPointRetreivalInRange() {
		//number of fields in a DataSet
		int n = 3;
		DataSet data= new DataSet(n);

		//add points by passing list of parameters
		data.addPoint(CompositeFeature.parseFeature("1"), CompositeFeature.parseFeature("3.5"), CompositeFeature.parseFeature("true"));
		data.addPoint(CompositeFeature.parseFeature("2"), CompositeFeature.parseFeature("4.5"), CompositeFeature.parseFeature("false"));
		data.addPoint(CompositeFeature.parseFeature("3"), CompositeFeature.parseFeature("5.5"), CompositeFeature.parseFeature("true"));

		//check retrievals
		assertNotNull(data.getPoint(2));
		assertTrue(data.getPoint(0).get(0).getContents() instanceof Integer);
		assertTrue(data.getPoint(1).get(2).getContents() instanceof Boolean);
		assertTrue(data.getPoint(2).get(1).getContents() instanceof Double);
	}

	/**
	 * ensure getPoint handles invalid indices correctly
	 */
	@Test
	public void testPointRetreivalOutOfRange() {
		//number of fields in a DataSet
		int n = 3;
		DataSet data= new DataSet(n);

		//add points by passing list of parameters
		data.addPoint(CompositeFeature.parseFeature("1"), CompositeFeature.parseFeature("3.5"), CompositeFeature.parseFeature("true"));
		data.addPoint(CompositeFeature.parseFeature("2"), CompositeFeature.parseFeature("4.5"), CompositeFeature.parseFeature("false"));
		data.addPoint(CompositeFeature.parseFeature("3"), CompositeFeature.parseFeature("5.5"), CompositeFeature.parseFeature("true"));

		//check retrievals
		assertNotNull(data.getPoint(2));
		assertNull(data.getPoint(3));
		assertNull(data.getPoint(-1));
	}
	
	@Test
	public void testInEqualityOfTwoDataSets(){
		int n = 3;
		DataSet data1= new DataSet(n);
		DataSet data2= new DataSet(n);

		//add points by passing list of parameters
		data1.addPoint(CompositeFeature.parseFeature("1"), CompositeFeature.parseFeature("3.5"), CompositeFeature.parseFeature("true"));
		data2.addPoint(CompositeFeature.parseFeature("2"), CompositeFeature.parseFeature("4.5"), CompositeFeature.parseFeature("false"));
		
		assertFalse(data1.equals(data2));
	}
	
	@Test
	public void testEqualityOfDataSetWithSelf(){
		int n = 3;
		DataSet data1= new DataSet(n);

		//add points by passing list of parameters
		data1.addPoint(CompositeFeature.parseFeature("1"), CompositeFeature.parseFeature("3.5"), CompositeFeature.parseFeature("true"));
		data1.addPoint(CompositeFeature.parseFeature("2"), CompositeFeature.parseFeature("4.5"), CompositeFeature.parseFeature("false"));
		
		assertTrue(data1.equals(data1));
	}
	
	@Test
	public void testEqualityOfTwoDataSets(){
		int n = 3;
		DataSet data1= new DataSet(n);
		DataSet data2= new DataSet(n);

		//add points by passing list of parameters
		data1.addPoint(CompositeFeature.parseFeature("1"), CompositeFeature.parseFeature("3.5"), CompositeFeature.parseFeature("(2, true)"));
		data1.addPoint(CompositeFeature.parseFeature("2"), CompositeFeature.parseFeature("4.5"), CompositeFeature.parseFeature("(4, false)"));
		
		data2.addPoint(CompositeFeature.parseFeature("1"), CompositeFeature.parseFeature("3.5"), CompositeFeature.parseFeature("(2, true)"));
		data2.addPoint(CompositeFeature.parseFeature("2"), CompositeFeature.parseFeature("4.5"), CompositeFeature.parseFeature("(4, false)"));
		
		assertTrue(data1.equals(data2));
	}
	
}
