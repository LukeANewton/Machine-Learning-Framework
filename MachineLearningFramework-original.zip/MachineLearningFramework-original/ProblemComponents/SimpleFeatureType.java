package ProblemComponents;

public enum SimpleFeatureType {
	BOOLEAN, CHARACTER, DOUBLE, INTEGER, STRING
}
