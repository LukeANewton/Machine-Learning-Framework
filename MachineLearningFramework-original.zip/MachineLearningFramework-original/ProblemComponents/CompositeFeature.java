package ProblemComponents;
import java.util.ArrayList;

import DistanceMetrics.DistanceFunction;

/**
 * Composite Features are features built out of other features. With simple
 * features and the ability to nest composite features, any type of data should be able to be included
 * 
 * Made up of a list of features, which can either be more composite features, or simple features.
 * 
 * Has getters and setters, a method to add another features to this composite, and a toString and toXML.
 * 
 * @author luke newton
 * @version 5
 */
public class CompositeFeature implements Feature {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3585080932376091941L;
	//list of features that make up this feature
	private ArrayList<Feature> contents;

	/**Constructor*/
	public CompositeFeature(){
		contents = new ArrayList<>();
	}

	/** returns the list of features that make up this feautre */
	public ArrayList<Feature> getContents() {
		return contents;
	}

	/** add another feature to the contents of this feature */
	public void addFeature(Feature feature){
		contents.add(feature);
	}

	/** converts the composite feature to a string */
	public String toString(){
		String s = "(";

		for(int i = 0; i < contents.size(); i++){
			s += contents.get(i).toString();

			if(i < contents.size() - 1)
				s += ", ";
		}
		s += ")";
		return s;
	}

	/**converts the composite feature into and XML ormatted string
	 * with at least n indentations*/
	public String toXML(){
		String s = "";

		//everything enclosed in a CompositeFeature tag
		s +="<CompositeFeature>";

		//iterate through contents in the contents tag to include each content in XML string
		s += "<contents>";
		for(int i = 0; i < contents.size(); i++){
			s += contents.get(i).toXML();
		}
		s += "</contents>";

		s += "</CompositeFeature>";

		return s;
	}

	/**creates appropriate tabbed spacing for XML formatting*/
	public String properXMLIndentation(int n){
		String s = "";

		for(int i = 0; i < n; i++)
			s += "\t";

		return s;
	}

	/** returns the feature at a specified index value, null if invalid range*/
	public Feature getFeature(int i) {
		if(i < contents.size() && i >= 0)
			return contents.get(i);
		return null;
	}

	/**
	 * Convert string into appropriate field type. Composite features must be enclosed in
	 * round brackets, with each sub-feature separated by a comma
	 * 
	 * @param s user text input of a field value
	 * @return a feature object containing data parsed from the input string
	 */
	public static Feature parseFeature(String s){
		if(s.equals(""))
			return null;

		//if enclosed in round brackets, its a composite feature
		if(s.charAt(0) == '(' && s.charAt(s.length()-1) == ')'){
			//build feature with this
			CompositeFeature compFeature = new CompositeFeature();
			//remove outer brackets from string
			String sNoBrackets = s.substring(1, s.length()-1);
			//split up sub-features by comma separation, unless were in a nested composite feature
			ArrayList<String> subFeatures = new ArrayList<>();
			subFeatures.add("");
			int inANestedFeature = 0;
			for(int i = 0 ,j = 0; i < sNoBrackets.length(); i++){

				//go to next substring on commas and when not in a nested composite feature
				if(sNoBrackets.charAt(i) == ',' && inANestedFeature == 0){
					j++;
					subFeatures.add("");
					//skip space
					i+=2;
				}

				if(sNoBrackets.charAt(i) == '('){
					inANestedFeature++;
				} else if (sNoBrackets.charAt(i) == ')'){
					inANestedFeature--;
				}

				subFeatures.set(j, (subFeatures.get(j) + sNoBrackets.charAt(i)));
			}

			//parse each sub string
			for(int i = 0; i < subFeatures.size(); i++){
				compFeature.addFeature(CompositeFeature.parseFeature(subFeatures.get(i)));
			}

			return compFeature;
		} else{
			//not enclosed in round brackets, should be a simple feature
			return SimpleFeature.parseSimpleFeature(s);
		}
	}

	/**override for this class' equals function*/
	@Override
	public boolean equals(Feature anotherFeature) {
		//if comparing a simple feature and composite feature, cannot be equal
		if(anotherFeature instanceof SimpleFeature)
			return false;

		//composite features must have the same number of sub features to be equal
		if(contents.size() != ((CompositeFeature)anotherFeature).getContents().size())
			return false;

		//iterate through subfeatures calling equals on each, if one is not equal, whole feature is not equal
		for(int i = 0; i < contents.size(); i++){
			if(!this.getFeature(i).equals(((CompositeFeature)anotherFeature).getFeature(i)))
				return false;
		}

		return true;
	}

	@Override
	public void setDistanceFunction(DistanceFunction distanceFunction, SimpleFeatureType simpleFeatureType) {
		for(int i = 0; i < contents.size(); i++){
			contents.get(i).setDistanceFunction(distanceFunction, simpleFeatureType);
		}
	}
}
