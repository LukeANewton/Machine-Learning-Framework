package ProblemComponents;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

import DistanceMetrics.DistanceFunction;


/**
 * Object containing all the necessary information to solve a problem. Includes the test examples, training examples,
 * weights for each feature in an example, and the name of each feature in an example
 * 
 * contains getters and setters for each above mentioned field, methods to add/remove training/test examples, a toString 
 * override, and a method to convert a problem into XML format.
 * 
 * @author luke newton
 * @version 3
 *
 */
public class Problem implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 321725887501432305L;
	//training exmaples are used to approximate outputs for test examples
	private DataSet trainingExamples;
	//collection of examples we want to predict the output for
	private DataSet testExamples;
	//the name of each feature in an example
	private ArrayList<String> fieldNames; 
	//the weightings to be applied to each feature in an exmaple
	private double[] weights;
	//keeps track of the accuracy of predictions made
	private PredictionError predictionError;

	//file name to read/write to/from
	private static final String FILENAMEXML = "problemXML.txt";
	private static final String FILENAMESERIALIZED = "problemSerialized.txt";

	/**constuctor*/
	public Problem(DataSet trainingExamples, DataSet testExamples, ArrayList<String> fieldNames, double[] weightings){
		this(trainingExamples, testExamples, weightings);
		this.fieldNames = fieldNames;
	}

	/**constuctor*/
	public Problem(DataSet trainingExamples, DataSet testExamples, double[] weightings){
		this(weightings);
		this.trainingExamples = trainingExamples;
		this.testExamples = testExamples;
	}

	/**constuctor*/
	public Problem(double[] weightings){
		this();
		this.weights = weightings;
	}

	/**constuctor*/
	public Problem(int n){
		this.trainingExamples = new DataSet(n);
		this.testExamples = new DataSet(n);
		this.fieldNames = new ArrayList<String>(n);
		this.weights = new double[n];
		this.predictionError = new PredictionError();
	}

	/**constuctor*/
	public Problem(int n, double[] weightings){
		this(n);
		this.weights = weightings;
	}

	/**constuctor*/
	public Problem(int n, ArrayList<String> fieldNames){
		this(n);
		this.fieldNames = fieldNames;

	}

	/**constuctor*/
	public Problem(int n, ArrayList<String> fieldNames, double[] weightings){
		this(n, fieldNames);
		this.weights = weightings;

	}

	/**constuctor*/
	public Problem(){
		this.trainingExamples = new DataSet();
		this.testExamples = new DataSet();
		this.fieldNames = new ArrayList<String>();
		this.predictionError = new PredictionError();
	}

	public PredictionError getPredictionError() {
		return predictionError;
	}
	
	/**
	 * updates the accuracy value this object contains
	 * NOTE: Since this should only be used for computer generated predictions and user defined predictions,
	 * it should only be passed to Objects of the same type. There are no checks for this, so if it is used incorrectly
	 * it is likely that the program will crash due incompatible classes compared with equals().
	 * 
	 * @param programPrediction the output value predicted by the call to Prediction.getPrediction()
	 * @param knownPrediction the known output of the test example, what we are trying to predict
	 * @return the updated accuracy of our prediction model
	 */
	public double updateAccuracy(Object programPrediction, Object knownPrediction){
		return predictionError.updateAccuracy(programPrediction, knownPrediction);
	}

	/**returns the collection of training examples*/
	public DataSet getTrainingExamples() {
		return trainingExamples;
	}

	/**returns a specified training example at index n*/
	public ArrayList<Feature> getTrainingExample(int n) {
		if(n >= 0 && n < trainingExamples.getNumberOfPoints())
			return trainingExamples.getPoint(n);
		return null;
	}

	/**set the training examples with a new collection of training examples*/
	public void setTrainingExamples(DataSet trainingExamples) {
		this.trainingExamples = trainingExamples;
	}

	/**returns the collection of test examples*/
	public DataSet getTestExamples() {
		return testExamples;
	}

	/**returns a specified test examples at index n*/
	public ArrayList<Feature> getTestExample(int n) {
		if(n >= 0 && n < testExamples.getNumberOfPoints())
			return testExamples.getPoint(n);
		return null;
	}

	/**set the test examples with a new collection of  test examples*/
	public void setTestExamples(DataSet testExamples) {
		this.testExamples = testExamples;
	}

	/**get the weightings for each feature*/
	public double[] getWeights() {
		return weights;
	}

	/**get a specified wweighting at index i*/
	public double getWeight(int i) {
		return weights[i];
	}

	/**set the weights with a new weight set*/
	public void setWeights(double[] weights) {
		this.weights = weights;
	}

	/**
	 * Returns the names of every field in the DataSet in an ArrayList
	 * 
	 * @return an ArrayList containing the name of every field as strings
	 */
	public ArrayList<String> getFieldNames(){
		return fieldNames;
	}

	/**
	 * Returns the name of a field in the DataSet at a specified index
	 * 
	 * @param n the index value of the field name to get
	 * 
	 * @return the name of the specified field
	 */
	public String getFieldName(int n){
		if(n >= 0 && n < fieldNames.size())
			return fieldNames.get(n);
		return null;
	}

	/**
	 * Set the field names by passing a list of names
	 * 
	 * @param names an ArrayList containing strings which correspond to the name of each field
	 */
	public void setFieldNames(ArrayList<String> names){
		fieldNames = names;
	}

	/**returns the number of features in each example*/
	public int getNumberOfAttributes(){
		return trainingExamples.getNumberOfAttributes();
	}

	/**sets the problem to havve examples with n attributes/exmaples*/
	public void setNumberOfAttributes(int n){
		trainingExamples.setNumberOfAttributes(n);
		testExamples.setNumberOfAttributes(n);
	}

	/**returns the number of training examples*/
	public int getNumberOfTrainingExamples(){
		return trainingExamples.getNumberOfPoints();
	}

	/**returns the number of test examples*/
	public int getNumberOfTestExamples(){
		return testExamples.getNumberOfPoints();
	}

	/**remove training example at index n*/
	public void removeTrainingExample(int n){
		trainingExamples.removePoint(n);
	}

	/**remove test exmaple at index n*/
	public void removeTestExample(int n){
		testExamples.removePoint(n);
	}

	/**add a training example by passing an array of features*/
	public int addTrainingExample(Feature... dataElements){
		return trainingExamples.addPoint(dataElements);
	}

	/**add a training example by passing an ArrayList of features*/
	public int addTrainingExample(ArrayList<Feature> dataElements){
		return trainingExamples.addPoint(dataElements);
	}
	
	/**edit a training example at index n in the collection*/
	public void editTrainingExample(int n, ArrayList<Feature> dataElements){
		trainingExamples.replacePoint(n, dataElements);
	}
	
	/**edit a test example at index n in the collection*/
	public void editTestExample(int n, ArrayList<Feature> dataElements){
		testExamples.replacePoint(n, dataElements);
	}

	/**add a test example by passing an array of features*/
	public int addTestExample(Feature... dataElements){
		return testExamples.addPoint(dataElements);
	}

	/**add a test example by passing an ArrayList of features*/
	public int addTestExample(ArrayList<Feature> dataElements){
		return testExamples.addPoint(dataElements);
	}

	public void setDistanceFunction(DistanceFunction distanceFunction, SimpleFeatureType simpleFeatureType){
			trainingExamples.setDistanceFunction(distanceFunction, simpleFeatureType);
			testExamples.setDistanceFunction(distanceFunction, simpleFeatureType);
	}
	
	/**to string override*/
	public String toString(){
		String s = "";

		s += "Training Exmaples:\n";
		s += trainingExamples.toString();

		s += "Test Exmaples:\n";
		s += testExamples.toString();

		s += "fieldNames:\n";
		for(int i = 0; i < fieldNames.size(); i++){
			s += fieldNames.get(i);
			if(i < fieldNames.size() - 1)
				s += ", ";
		}

		s += "\nweights:\n";
		for(int i = 0; i < weights.length; i++){
			s += weights[i];
			if(i < weights.length - 1)
				s += ", ";
		}

		return s;
	}

	/**create an XML formatted string*/
	public String toXML(){
		String s = "";

		//everything enclosed in a problem tag
		s += "<Problem>";

		//training exmaple tag for first field in a problem
		s += "<trainingExamples>";
		s += trainingExamples.toXML();
		s += "</trainingExamples>";

		//test exmple tag for the second field in a problem
		s += "<testExamples>";
		s += testExamples.toXML();
		s += "</testExamples>";

		//fieldNames tag for the thrid field in a problem
		s += "<fieldNames>";
		for(int i = 0; i < fieldNames.size(); i++){
			s += "<fieldName>";
			s += fieldNames.get(i);
			s += "</fieldName>";
		}
		s += "</fieldNames>";

		//weights tag for the last field in a problem
		s += "<weights>";
		for(int i = 0; i < fieldNames.size(); i++){
			s += "<weight>";
			s += weights[i];
			s += "</weight>";
		}
		s += "</weights>";

		s += "</Problem>";

		return s;
	}

	public boolean equals(Problem anotherProblem){
		return trainingExamples.equals(anotherProblem.getTrainingExamples()) &&
				testExamples.equals(anotherProblem.getTestExamples()) &&
				fieldNames.equals(anotherProblem.getFieldNames()) &&
				weights.equals(anotherProblem.getWeights());
	}

	/**saves problem as an XML foramtted text document specified by constant FILENAME*/
	public void exportToXMLFile(){
		String s = this.toXML();

		try {
			//write to file
			BufferedWriter out = new BufferedWriter(new FileWriter(FILENAMEXML));
			out.write(s);
			out.close();
		} catch (IOException e1) {
			System.out.println("Failed to write to file");
		}
	}

	/**
	 * serialized export for an address book
	 * 
	 * @throws IOException
	 */
	public void serializedExport() throws IOException {
		FileOutputStream fileOut = null;
		try {
			fileOut = new FileOutputStream(FILENAMESERIALIZED);
		} catch (FileNotFoundException e1) {
			System.out.println("file not found");
			System.exit(0);
		}
		
		ObjectOutputStream out;
		out = new ObjectOutputStream(fileOut);
		
		out.writeObject(this);
		out.close();
		fileOut.close();
	}
	
	/**
	 * import serialized address book
	 * 
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	public void serializedImport() throws IOException, ClassNotFoundException {
		FileInputStream fileIn = null;
		try {
			fileIn = new FileInputStream(FILENAMESERIALIZED);
		} catch (FileNotFoundException e1) {
			System.out.println("file not found");
			System.exit(0);
		}
		
		ObjectInputStream in = new ObjectInputStream(fileIn);
		
		Problem newProblem = (Problem)in.readObject();
		
		trainingExamples = newProblem.getTrainingExamples();
		testExamples = newProblem.getTestExamples();
		fieldNames = newProblem.getFieldNames();
		weights = newProblem.getWeights();
		
		in.close();
		fileIn.close();
	}
}
