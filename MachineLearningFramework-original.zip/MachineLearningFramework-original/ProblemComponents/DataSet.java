package ProblemComponents;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.DefaultListModel;

import DistanceMetrics.DistanceFunction;

/**
 * This class is used as the data structure for holding all our information we need to  estimate the value of a new point.
 * 
 * As of right now, it contains fields for the number of data points within the structure and number of elements in each point
 * as well as the data storage itself. It also contains a list of names for each attribute (column) and list of each attribute 
 * type (may be removed later)
 * 
 * This class contains methods for creating a completely empty table, creating a table with
 * space for a specified number of elements in a point, adding space for more elements in each point, adding a point to the data
 * set, printing the data set in its entirety, and methods for getting the number of points in the data set, number of elements 
 * in each point, getting a specified point, and getting the data structure as a whole. 
 * 
 * @author luke newton
 * @version 7
 */
public class DataSet implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 14930272538704319L;
	private DefaultListModel<ArrayList<Feature>> dataSet;
	//number of attributes in the DataSet (number of elements in each point)
	private int numberOfAttributes;

	/**
	 *Constructor for Data Set, initializes a table to hold data points
	 *
	 *@param n integer representing the number of elements in each data point
	 */
	public DataSet(int n){
		this.dataSet = new DefaultListModel<>();
		numberOfAttributes = n;
	}

	/**
	 *Constructor for Data Set, initializes an empty table to hold data points
	 */
	public DataSet(){
		this.dataSet = new DefaultListModel<>();
		numberOfAttributes = 0;
	}

	/**
	 * Return the entire dataSet
	 * 
	 * @return a 2D ArrayList containing all the point data
	 */
	public DefaultListModel<ArrayList<Feature>> getDataSet() {
		return dataSet;		
	}


	/**
	 *Return the number of points held in the dataSet
	 *
	 *@return the number of points contained in the data set
	 */
	public int getNumberOfPoints() {
		return dataSet.size();
	}

	/**
	 * Return number of attributes in the DataSet (number of elements in each point)
	 * 
	 * @return the number of elements in a data point
	 */
	public int getNumberOfAttributes() {
		return numberOfAttributes;
	}

	/**sets the number of attributes for a DataSet*/
	public void setNumberOfAttributes(int n){
		numberOfAttributes = n;
	}

	public void setDistanceFunction(DistanceFunction distanceFunction, SimpleFeatureType simpleFeatureType){
		for(int i = 0; i < getNumberOfPoints(); i++){
			for(int j = 0; j < getNumberOfAttributes(); j++){
				if(getPoint(i).get(j) != null)
					getPoint(i).get(j).setDistanceFunction(distanceFunction, simpleFeatureType);
			}
		}
	}

	/**
	 * Removes a point from the data set at a specified index 
	 * 
	 * @param indexNum the index number of the point to remove
	 */
	public void removePoint(int indexNum){
		//if specified index is out of range of dataset, do not remove anything
		if(indexNum < 0 || indexNum >= dataSet.getSize()){
			return;
		}

		dataSet.removeElementAt(indexNum);
	}

	/**
	 * Checks two DataSet objects for equality
	 * 
	 * @param anotherSet a DataSet to compare to this DataSet
	 * @return returns true if tthe two DataSets contain all equal fields
	 */
	public boolean equals(DataSet anotherSet){	
		if(this.numberOfAttributes != anotherSet.getNumberOfAttributes())
			return false;

		if(this.getNumberOfPoints() != anotherSet.getNumberOfPoints())
			return false;

		for(int i = 0; i < this.getNumberOfPoints(); i++){
			for(int j = 0; j < this.getNumberOfAttributes(); j++){
				if(!this.getPoint(i).get(j).equals(anotherSet.getPoint(i).get(j)))
					return false;
			}
		}

		return true;
	}

	/**
	 * Adds a point to the data set
	 * 
	 * @param list separated by commas of each element in the point
	 * @return 0 if successful or -1 if unsuccessful (ie. number of passed parameters != number of rows in DataSet)
	 */
	public int addPoint(Feature... dataElements){
		if(dataElements.length == numberOfAttributes){
			this.dataSet.addElement(new ArrayList<>(Arrays.asList(dataElements)));
			return 0;
		}else 
			return -1;
	}

	/**
	 * Adds a point to the data set
	 * 
	 * @param dataElements ArrayList containing each element in the point
	 * @return 0 if successful or -1 if unsuccessful (ie. number of passed parameters != number of rows in DataSet)
	 */
	public int addPoint(ArrayList<Feature> dataElements){
		if(dataElements.size() == numberOfAttributes){
			System.out.println(this.dataSet);
			this.dataSet.addElement(dataElements);
			return 0;
		}else 
			return -1;
	}

	/**
	 * replace a point in a dataSet with another point
	 * 
	 * @param n index of the point in the DataSet to replace
	 * @param dataElements ArrayList containing each element in the point
	 */
	public void replacePoint(int n, ArrayList<Feature> dataElements){
		this.dataSet.set(n, dataElements);
	}

	/**override of Object's toSting() method*/
	public String toString(){
		String s = "";

		//using getPoint method, iterate through each point
		for(int i = 0; i < dataSet.size(); i++){
			s += dataSet.getElementAt(i).toString() + "\n";
		}
		return s;

	}

	/**convert DataSet into XML forammtted string*/
	public String toXML(){
		String s = "";

		//numberOFAttributes tag for second field in DataSet
		s += "<numberOfAttributes>";
		s += numberOfAttributes;
		s += "</numberOfAttributes>";

		//dataSet tag for first field in a DataSet
		s += "<dataSet>";
		for(int i = 0; i < getNumberOfPoints(); i++){
			//iterate through each example and feature in each example to add to string
			s += "<Example>";
			for(int j = 0; j < getNumberOfAttributes(); j++){
				s += dataSet.getElementAt(i).get(j).toXML();
			}
			s += "</Example>";
		}
		s += "</dataSet>";
		return s;
	}

	/**
	 * Prints the entire data set as a list of points
	 */
	public void printData(){
		System.out.print(this.toString());
		System.out.println();
	}

	/**
	 * Returns a specified point within the DataSet
	 * 
	 * @param pointNum an integer representing the number of the point that is required to be returned
	 * 
	 * @return  an ArrayList containing each element of the point as a separate element of the ArrayList
	 */
	public ArrayList<Feature> getPoint(int pointNum){
		if(pointNum >= 0 && pointNum < dataSet.getSize()){
			return dataSet.getElementAt(pointNum);
		}
		//specified point is out of range of DataSet
		return null;
	}
}
